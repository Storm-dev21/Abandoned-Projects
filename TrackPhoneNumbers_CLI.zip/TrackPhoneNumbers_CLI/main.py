import phonenumbers
from phonenumbers import geocoder,carrier
import os
import time
import pycountry

global InteredPoneN


def uknowncontry():
    
    global InteredPoneN
    def get_country_code(country_name):
        country = pycountry.countries.get(name=country_name)
        if not country:
            return None
        
        country_code = phonenumbers.country_code_for_region(country.alpha_2)
        return country_code
    
    while 1==1:
        global InteredPoneN
        try:
            types = input('\n(1) country code (find its name by The Code) \n(2) country name (Find it code by The Name) \nenter \'back\' to go back\n\noptions :> ')
            if types == '1) country code' or types == '1':
                os.system('cls')
                def get_country_by_code(phone_code):
                    phone_code_str = f"+{phone_code}"
                    try:
                        region_code = phonenumbers.region_code_for_country_code(int(phone_code))
                    except KeyError:
                        return None
                    
                    if not region_code:
                        return None
                    
                    country = pycountry.countries.get(alpha_2=region_code)
                    if country:
                        return country.name
                        
                    return None

                while 1==1:
                    try:
                        phone_code = input('Country Code :> ')

                        country_name = get_country_by_code(phone_code)
                        if country_name:
                            print(f"The country with phone code +{phone_code} is {country_name}.")
                            continue
                        elif country_name == 'back':
                            main()
                        else:
                            print(f"No country found with phone code +{phone_code}.")
                    except KeyboardInterrupt:
                        quit()
                    
            elif types == '2) contry name' or types == '2':
                os.system('cls')
                country_name = input('conrty name :> ')
                country_code = get_country_code(country_name)
                if country_name == '':
                    print(' ( ! ) please insert conrty name! ( ! ) ')
                elif country_name == 'back':
                    main()
                elif country_code:
                    print(f"( * ) The phone number code for {country_name} is +{country_code}  ( * ) \n")
                    continue

                else:
                    print(f"( ! ) Country code for {country_name} not found ( ! ) ")
            elif types == 'back':
                print('\n')
                main()
            else:
                print('( ! ) uknown option! ( ! ) ')
                continue
        except Exception:
            pass




def PhoneContry(Phone):
    global InteredPoneN
    conrty = (geocoder.description_for_number(Phone,'en'))
    if conrty == '':
        print('[!] ENTER A VAILD PHONE NUMBER [!]')
    else: 
        message = '\nPhone : '+InteredPoneN+'''\nconrty : '''+conrty+'\n'
        print(message)
        time.sleep(0.025)

def carrier1(Phone):
    global InteredPoneN
    carrier_ = (carrier.name_for_number(Phone,'en'))
    if carrier_ == '':
        print('[!] POHNE NUMBER IS WRONG!! OR CARRIER FOUND! [!]')
    else:   
        message = '\nPhone : '+InteredPoneN+'''\ncarrier : '''+carrier_+'\n'
        print(message)
        time.sleep(0.025)

def main():
    global InteredPoneN,Phone
    while True:
        try:
            #main logo
            q = input('''what data u want to execute from? -h for help\n\n(1) contry   (2) carrier(phone number company)\n(4) timezones (5) all (6) contry (name/code)\nOption :> ''')
            if q == 'contry' or q=='1)contry' or q=='1':
                InteredPoneN=input('Phone number :>')
                Phone = phonenumbers.parse(InteredPoneN,None)
                PhoneContry(Phone)
            elif q=='clear' or q=='cls':
                os.system('cls')
            elif q=='':
                os.system('cls')
                continue
            elif q=='-h':
                print('\nUsage : <ConrtyCode><Pohnenumber>\n\n  Example:\n         +1 233829321\n')
                continue
            elif q== 'carrier' or q == '2)carrier' or q=='2':
                InteredPoneN=input('Phone number :>')
                Phone = phonenumbers.parse(InteredPoneN,None)
                carrier1(Phone)

            elif q== 'timezones' or q == '4)all' or q=='4':
                
                print('timezone')
            elif q== 'contry (name/code)' or q =='contry (name/code)' or q=='6':
                uknowncontry()

            elif q=='quit' or q == 'exit'  or q=='99':
                print('quit!')
                quit()
                
            else:
                print('( ! ) Error! uknown oprator! ( ! )')
                time.sleep(1)
                os.system('cls')   
                continue
        except KeyboardInterrupt:
                break


main()