from customtkinter import *
from PIL import Image


def start_():

    root = CTk()
    root.title("StormTools Network Hacker 1.0")
    root.geometry("1240x773+340+154")
    #root.iconbitmap("")
    root.configure(fg_color="black")


    Logo=CTkImage(dark_image=Image.open("icons//Logo.png"),size=(867, 214))

    Logo_holder=CTkLabel(master=root,image=Logo,text=" ")
    Logo_holder.pack()



    root.mainloop()



if __name__=="__main__":
    start_()